cp is truncated
             3             1             1             1
iua                        4             4            16             0
(26I3)          (40I2)          (26I3)              
  1  5  9
